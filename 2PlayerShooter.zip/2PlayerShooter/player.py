import pygame
import math

class Player:
    health_bar_width = 80
    health_bar_height = 10

    def __init__(self, x, y, speed, health, weapon, angle, image, screen):
        self.x = x
        self.y = y
        self.speed = speed
        self.health = health
        self.weapon = weapon
        self.angle = angle
        self.image = pygame.image.load(image)
        self.rotated_image = pygame.transform.rotate(self.image, angle)
        self.rect = self.rotated_image.get_rect(center=(x, y))
        self.hitbox_rect = pygame.Rect(0, 0, 57, 57)
        self.hitbox_rect.center = self.rect.center
        self.hitbox_rect.move_ip(47, 47)
        self.screen = screen

    def move_up(self):
        self.x += self.speed * math.cos(math.radians(self.angle))
        self.y -= self.speed * math.sin(math.radians(self.angle))
        self.rotated_image = pygame.transform.rotate(self.image, self.angle)
        self.rect = self.rotated_image.get_rect(center=(self.x, self.y))
        self.rect.clamp_ip(self.screen.get_rect())
        self.hitbox_rect.center = self.rect.center

    def move_down(self):
        self.y += self.speed
        self.rotated_image = pygame.transform.rotate(self.image, self.angle)
        self.rect = self.rotated_image.get_rect(center=(self.x, self.y))
        self.rect.clamp_ip(self.screen.get_rect())
        self.hitbox_rect.center = self.rect.center

    def move_left(self):
        self.angle += 1.5
        self.rotated_image = pygame.transform.rotate(self.image, self.angle)
        self.rect = self.rotated_image.get_rect(center=(self.x, self.y))
        self.hitbox_rect.center = self.rect.center

    def move_right(self):
        self.angle -= 1.5
        self.rotated_image = pygame.transform.rotate(self.image, self.angle)
        self.rect = self.rotated_image.get_rect(center=(self.x, self.y))
        self.hitbox_rect.center = self.rect.center

    def draw_health_bar(self, screen):
        health_percent = self.health / 100
        health_bar_width = self.health_bar_width * health_percent
        health_bar = pygame.Rect(0, 0, health_bar_width, self.health_bar_height)

        border_rect = pygame.Rect(0, 0, self.health_bar_width + 6, self.health_bar_height + 6)
        border_rect.center = self.rect.center
        border_rect.move_ip(0, -60)
        pygame.draw.rect(screen, (51, 54, 51, 150), border_rect)

        health_bar.center = border_rect.center
        health_bar.left = border_rect.left + 3

        pygame.draw.rect(screen, (127, 195, 73), health_bar)
