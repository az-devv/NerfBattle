import pygame
import time
import random
import math
from player import Player
from bullet import Bullet
from cpu_player import CPUPlayer

pygame.init()

screen_width = 1510
screen_height = 827
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("2 Player Shooter Game")

def initialize_game():
    player1_last_shot_time = time.time()
    player1_bullet_delay = 0.15

    player2_last_shot_time = time.time()
    player2_bullet_delay = 0.15

    player1_bullets = []
    player2_bullets = []

    bg_tile = pygame.image.load("background.png")
    bg_width, bg_height = bg_tile.get_size()
    bg_surface = pygame.Surface((screen_width, screen_height))
    for x in range(0, screen_width, bg_width):
        for y in range(0, screen_height, bg_height):
            bg_surface.blit(bg_tile, (x, y))

    player1 = Player(100, 100, 3, 100, "Pistol", 180, "Player1.png", screen)
    player2 = Player(screen_width - 100, screen_height - 100, 3, 100, "Pistol", 0, "Player2.png", screen)

    done = False

    while not done:
        screen.fill((0, 0, 0))
        screen.blit(bg_surface, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True

        for bullet in player1_bullets:
            bullet.update_pos()
            if player2.hitbox_rect.colliderect(bullet.rect):
                player2.health -= 8
                player1_bullets.remove(bullet)

        for bullet in player2_bullets:
            bullet.update_pos()
            if player1.hitbox_rect.colliderect(bullet.rect):
                player1.health -= 8
                player2_bullets.remove(bullet)

        if player1.health <= 0 or player2.health <= 0:
            done = True

        current_time = time.time()
        keys = pygame.key.get_pressed()

        if keys[pygame.K_d]:
            player1.move_right()
        if keys[pygame.K_a]:
            player1.move_left()
        if keys[pygame.K_w]:
            player1.move_up()
        if keys[pygame.K_t]:
            if current_time - player1_last_shot_time > player1_bullet_delay:
                deviation = random.randint(-5, 5)
                bullet_angle = player1.angle + deviation
                bullet = Bullet(player1.x, player1.y, bullet_angle)
                player1_bullets.append(bullet)
                player1_last_shot_time = current_time

        if keys[pygame.K_RIGHT]:
            player2.move_right()
        if keys[pygame.K_LEFT]:
            player2.move_left()
        if keys[pygame.K_UP]:
            player2.move_up()
        if keys[pygame.K_m]:
            if current_time - player2_last_shot_time > player2_bullet_delay:
                deviation = random.randint(-5, 5)
                bullet_angle = player2.angle + deviation
                bullet = Bullet(player2.x, player2.y, bullet_angle)
                player2_bullets.append(bullet)
                player2_last_shot_time = current_time

        player1.x, player1.y = player1.rect.center
        player2.x, player2.y = player2.rect.center

        screen.blit(player1.rotated_image, player1.rect)
        screen.blit(player2.rotated_image, player2.rect)
        player1.draw_health_bar(screen)
        player2.draw_health_bar(screen)

        for bullet in player1_bullets:
            bullet.update_pos()
            bullet_rect = bullet.bullet_image.get_rect(center=(bullet.x, bullet.y))
            rotated_bullet = pygame.transform.rotate(bullet.bullet_image, bullet.angle)
            rotated_bullet = pygame.transform.scale(rotated_bullet, (20, 20))
            rotated_bullet_rect = rotated_bullet.get_rect(center=(bullet.x, bullet.y))
            screen.blit(rotated_bullet, rotated_bullet_rect)

        for bullet in player2_bullets:
            bullet.update_pos()
            bullet_rect = bullet.bullet_image.get_rect(center=(bullet.x, bullet.y))
            rotated_bullet = pygame.transform.rotate(bullet.bullet_image, bullet.angle)
            rotated_bullet = pygame.transform.scale(rotated_bullet, (20, 20))
            rotated_bullet_rect = rotated_bullet.get_rect(center=(bullet.x, bullet.y))
            screen.blit(rotated_bullet, rotated_bullet_rect)

        pygame.display.flip()

    darken_surface = pygame.Surface((screen_width, screen_height))
    darken_surface.fill((0, 0, 0))
    darken_surface.set_alpha(160)

    screen.blit(darken_surface, (0, 0))

    font = pygame.font.Font("OpenSans-Bold.ttf", 40)

    if player1.health <= 0:
        message1 = "Eliminated By"
        message2 = "Player 2"
        color = (187, 76, 84)
    else:
        message1 = "Eliminated By"
        message2 = "Player 1"
        color = (187, 76, 84)

    text_surface1 = font.render(message1, True, (255, 255, 255))
    text_rect1 = text_surface1.get_rect()
    text_rect1.centerx = screen.get_rect().centerx
    text_rect1.y = screen.get_rect().y + 50

    text_surface2 = font.render(message2, True, color)
    text_rect2 = text_surface2.get_rect()
    text_rect2.centerx = screen.get_rect().centerx
    text_rect2.y = text_rect1.y + text_rect1.height

    screen.blit(text_surface1, text_rect1)
    screen.blit(text_surface2, text_rect2)

    again_image = pygame.image.load('PlayAgain.png')
    again_image = pygame.transform.scale(again_image, (261.3, 81.25))

    leave_image = pygame.image.load('BackButton.png')
    leave_image = pygame.transform.scale(leave_image, (101.16, 81.25))

    again_rect = again_image.get_rect()
    leave_rect = leave_image.get_rect()

    screen_rect = screen.get_rect()

    center_x = screen_rect.centerx - (leave_rect.width + 10 + again_rect.width) / 2

    leave_rect.left = center_x
    leave_rect.bottom = screen.get_rect().bottom - 50

    again_rect.left = leave_rect.right + 10
    again_rect.bottom = leave_rect.bottom

    screen.blit(leave_image, leave_rect)
    screen.blit(again_image, again_rect)

    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if again_rect.collidepoint(event.pos):
                    initialize_game()
                elif leave_rect.collidepoint(event.pos):
                    display_menu(player1)


def initialize_game_with_cpu(player1):
    player1_last_shot_time = time.time()
    player1_bullet_delay = 0.75
    player1_bullets = []

    bg_tile = pygame.image.load("background.png")
    bg_width, bg_height = bg_tile.get_size()
    bg_surface = pygame.Surface((screen_width, screen_height))
    for x in range(0, screen_width, bg_width):
        for y in range(0, screen_height, bg_height):
            bg_surface.blit(bg_tile, (x, y))

    player1 = Player(100, 100, 3, 100, "Pistol", 180, "Player1.png", screen)
    cpu_player = CPUPlayer(screen_width - 100, screen_height - 100, 3, screen, player1)

    done = False

    while not done:
        screen.fill((0, 0, 0))
        screen.blit(bg_surface, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True

        current_time = time.time()
        keys = pygame.key.get_pressed()

        if keys[pygame.K_d]:
            ''
            player1.move_right()
        if keys[pygame.K_a]:
            player1.move_left()
        if keys[pygame.K_w]:
            player1.move_up()
        if keys[pygame.K_t]:
            if current_time - player1_last_shot_time > player1_bullet_delay:
                deviation = random.randint(-5, 5)
                bullet_angle = player1.angle + deviation
                bullet = Bullet(player1.x, player1.y, bullet_angle)
                player1_bullets.append(bullet)
                player1_last_shot_time = current_time

        player1.x, player1.y = player1.rect.center
        screen.blit(player1.rotated_image, player1.rect)
        player1.draw_health_bar(screen)

        for bullet in player1_bullets:
            bullet.update_pos()
            bullet_rect = bullet.bullet_image.get_rect(center=(bullet.x, bullet.y))
            rotated_bullet = pygame.transform.rotate(bullet.bullet_image, bullet.angle)
            rotated_bullet = pygame.transform.scale(rotated_bullet, (20, 20))
            rotated_bullet_rect = rotated_bullet.get_rect(center=(bullet.x, bullet.y))
            screen.blit(rotated_bullet, rotated_bullet_rect)

        for bullet in player1_bullets:
            bullet.update_pos()
            if cpu_player.rect.colliderect(bullet.rect):
                cpu_player.health -= 8
                player1_bullets.remove(bullet)

        for bullet in cpu_player.bullets:
            bullet.update_pos()
            if player1.rect.colliderect(bullet.rect):
                player1.health -= 8
                cpu_player.bullets.remove(bullet)

        if player1.health <= 0 or cpu_player.health <= 0:
            done = True

        cpu_player.update()
        cpu_player.draw(screen)
        pygame.display.flip()

    darken_surface = pygame.Surface((screen_width, screen_height))
    darken_surface.fill((0, 0, 0))
    darken_surface.set_alpha(160)

    screen.blit(darken_surface, (0, 0))

    font = pygame.font.Font("OpenSans-Bold.ttf", 40)

    if player1.health <= 0:
        message1 = "Eliminated By"
        message2 = "CPU Player"
        color = (187, 76, 84)
    else:
        message1 = "Eliminated CPU Player"
        message2 = "Player 1"
        color = (187, 76, 84)

    text_surface1 = font.render(message1, True, (255, 255, 255))
    text_rect1 = text_surface1.get_rect()
    text_rect1.centerx = screen.get_rect().centerx
    text_rect1.y = screen.get_rect().y + 50

    text_surface2 = font.render(message2, True, color)
    text_rect2 = text_surface2.get_rect()
    text_rect2.centerx = screen.get_rect().centerx
    text_rect2.y = text_rect1.y + text_rect1.height

    screen.blit(text_surface1, text_rect1)
    screen.blit(text_surface2, text_rect2)

    again_image = pygame.image.load('PlayAgain.png')
    again_image = pygame.transform.scale(again_image, (261.3, 81.25))

    leave_image = pygame.image.load('BackButton.png')
    leave_image = pygame.transform.scale(leave_image, (101.16, 81.25))

    again_rect = again_image.get_rect()
    leave_rect = leave_image.get_rect()

    screen_rect = screen.get_rect()

    center_x = screen_rect.centerx - (leave_rect.width + 10 + again_rect.width) / 2

    leave_rect.left = center_x
    leave_rect.bottom = screen.get_rect().bottom - 50

    again_rect.left = leave_rect.right + 10
    again_rect.bottom = leave_rect.bottom

    screen.blit(leave_image, leave_rect)
    screen.blit(again_image, again_rect)

    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if again_rect.collidepoint(event.pos):
                    initialize_game_with_cpu(player1)
                elif leave_rect.collidepoint(event.pos):
                    display_menu(player1)


def display_menu(player1):
    background_image = pygame.image.load("gamebg.png")
    background_image = pygame.transform.scale(background_image, (screen_width, screen_height))
    background_image = pygame.transform.smoothscale(background_image, (screen_width // 10, screen_height // 10))
    background_image = pygame.transform.smoothscale(background_image, (screen_width, screen_height))

    screen.blit(background_image, (0, 0))

    logo_image = pygame.image.load("logo.png")
    logo_width, logo_height = logo_image.get_size()

    logo_scale = 0.25
    logo_image = pygame.transform.scale(logo_image, (int(logo_width * logo_scale), int(logo_height * logo_scale)))

    logo_rect = logo_image.get_rect(center=(screen_width // 2, screen_height // 4))
    screen.blit(logo_image, logo_rect)

    p1_button = pygame.image.load("p1.png")
    p2_button = pygame.image.load("p2.png")

    button_scale = 0.5
    p1_button = pygame.transform.scale(p1_button, (int(p1_button.get_width() * button_scale), int(p1_button.get_height() * button_scale)))
    p2_button = pygame.transform.scale(p2_button, (int(p2_button.get_width() * button_scale), int(p2_button.get_height() * button_scale)))

    p1_rect = p1_button.get_rect(center=(screen_width // 2 - 150, screen_height // 2))
    p2_rect = p2_button.get_rect(center=(screen_width // 2 + 150, screen_height // 2))

    screen.blit(p1_button, p1_rect)
    screen.blit(p2_button, p2_rect)

    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if p1_rect.collidepoint(event.pos):
                    initialize_game()
                elif p2_rect.collidepoint(event.pos):
                    initialize_game_with_cpu(player1)



player1 = Player(100, 100, 3, 100, "Pistol", 180, "Player1.png", screen)
display_menu(player1)
