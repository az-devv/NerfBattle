import pygame
import math
import random
from bullet import Bullet
import time

class CPUPlayer:
    health_bar_width = 80
    health_bar_height = 10

    def __init__(self, x, y, speed, screen, target):
        self.x = x
        self.y = y
        self.speed = speed
        self.screen = screen
        self.target = target
        self.image = pygame.image.load("Player2.png")
        self.rect = self.image.get_rect(center=(self.x, self.y))
        self.angle = 0
        self.health = 100
        self.bullets = []
        self.bullet_delay = 1
        self.last_shot_time = pygame.time.get_ticks() / 1000

    def move_towards_player(self):
        dx = self.target.rect.centerx - self.rect.centerx
        dy = self.target.rect.centery - self.rect.centery
        angle_to_player = math.degrees(math.atan2(-dy, dx))
        angle_diff = angle_to_player - self.angle
        if angle_diff > 180:
            angle_diff -= 360
        elif angle_diff < -180:
            angle_diff += 360
        rotation_speed = min(1.5, abs(angle_diff))
        if angle_diff > 0:
            self.angle += rotation_speed
        else:
            self.angle -= rotation_speed

        if self.move_forward:
            move_x = math.cos(math.radians(self.angle)) * self.speed
            move_y = -math.sin(math.radians(self.angle)) * self.speed
            self.rect.centerx += move_x
            self.rect.centery += move_y

        self.rect.clamp_ip(self.screen.get_rect())

    def draw_health_bar(self):
        health_percent = self.health / 100
        health_bar_width = self.health_bar_width * health_percent
        health_bar = pygame.Rect(0, 0, health_bar_width, self.health_bar_height)

        border_rect = pygame.Rect(0, 0, self.health_bar_width + 6, self.health_bar_height + 6)
        border_rect.center = self.rect.center
        border_rect.move_ip(0, -60)
        pygame.draw.rect(self.screen, (51, 54, 51, 150), border_rect)

        health_bar.center = border_rect.center
        health_bar.left = border_rect.left + 3

        pygame.draw.rect(self.screen, (127, 195, 73), health_bar)

    def update(self):
        if random.random() < 0.5:
            self.move_forward = True
        else:
            self.move_forward = False

        self.move_towards_player()

        current_time = pygame.time.get_ticks() / 1000
        if current_time - self.last_shot_time > self.bullet_delay:
            target_angle = self.angle
            deviation = random.randint(-5, 5)
            bullet_angle = target_angle + deviation
            bullet = Bullet(self.rect.centerx, self.rect.centery, bullet_angle)
            self.bullets.append(bullet)
            self.last_shot_time = current_time

    def draw(self, screen):
        rotated_image = pygame.transform.rotate(self.image, self.angle)
        self.rect = rotated_image.get_rect(center=self.rect.center)

        screen.blit(rotated_image, self.rect)

        for bullet in self.bullets:
            bullet.update_pos()
            rotated_bullet = pygame.transform.rotate(bullet.bullet_image, bullet.angle)
            rotated_bullet = pygame.transform.scale(rotated_bullet, (20, 20))
            rotated_bullet_rect = rotated_bullet.get_rect(center=(bullet.x, bullet.y))
            screen.blit(rotated_bullet, rotated_bullet_rect)

        self.draw_health_bar()

