import pygame
import math

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, angle):
        super().__init__()
        self.x = x
        self.y = y
        self.angle = angle
        self.speed = 8
        self.bullet_image = pygame.image.load('bullet.png')
        self.bullet_image = pygame.transform.scale(self.bullet_image, (10, 10))
        self.rect = self.bullet_image.get_rect(center=(x, y))

    def update_pos(self):
        bullet_dx = self.speed * math.cos(math.radians(self.angle))
        bullet_dy = self.speed * math.sin(math.radians(self.angle))
        self.x += bullet_dx
        self.y -= bullet_dy
        self.rect.center = (self.x, self.y)

    def add_internal(self, group):
        super().add_internal(group)
